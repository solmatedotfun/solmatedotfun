import React from "react";
import SolMate from "./SolMate";

function App() {
  return <SolMate />;
}

export default App;